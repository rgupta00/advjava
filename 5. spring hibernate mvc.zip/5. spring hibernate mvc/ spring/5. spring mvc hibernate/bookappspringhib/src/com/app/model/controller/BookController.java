package com.app.model.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.model.dao.Book;
import com.app.model.service.BookService;

@Controller
public class BookController {

	@Autowired
	private BookService bookService;
	

	@RequestMapping(value="showallbooks", method=RequestMethod.GET)
	public String showAllBooks(ModelMap map){
		map.addAttribute("books", bookService.getAllBooks());
		return "showallbooks";
	}
	
	@RequestMapping(value="addbook", method=RequestMethod.GET)
	public String showBookForm(ModelMap map){
		map.addAttribute("book", new Book());
		return "addbook";
	}
	
	@RequestMapping(value="updatebook", method=RequestMethod.GET)
	public String updateBook(ModelMap map, HttpServletRequest request){
		int id=Integer.parseInt(request.getParameter("id"));
		Book book=bookService.getBookById(id);
		map.addAttribute("book", book);
		return "addbook";
	}
	
	
	@RequestMapping(value="deletebook", method=RequestMethod.GET)
	public String deleteBook(HttpServletRequest request){
		int id=Integer.parseInt(request.getParameter("id"));
		
		bookService.removeBook(id);
		return "redirect:/showallbooks";
	}
	//@valid must ==>BindingResult
	@RequestMapping(value="addbook", method=RequestMethod.POST)
	public String saveBook( @ModelAttribute(value="book") @Valid Book book, ModelMap map,
			BindingResult bindingResult  ){
		if(bindingResult.hasErrors()){
			return "addbook";
		}else{
			if(book.getId()==0)
				bookService.addBook(book);
			else
				bookService.updateBook(book);
			return "redirect:/showallbooks";
		}
		
	}
	
}
